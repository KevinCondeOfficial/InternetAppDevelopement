<?php
// bmi_calculator.php
//Kevin Conde
?>
<!DOCTYPE html>
<html>
<head><title>BMI Calculator</title></head>
<body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $heightFeet = $_POST["heightFeet"];
    $heightInches = $_POST["heightInches"];
    $weight = $_POST["weight"];

    $totalInches = ($heightFeet * 12) + $heightInches;
    $bmi = 703 * $weight / ($totalInches * $totalInches);
    $bmi = round($bmi, 1);

    if ($bmi < 18.5) $meaning = "underweight";
    elseif ($bmi < 24.9) $meaning = "normal weight";
    elseif ($bmi < 29.9) $meaning = "overweight";
    else $meaning = "obese";

    echo "<h3>Hi $name,</h3>";
    echo "<p>You are a $gender. You are $age years old.</p>";
    echo "<p>You are currently $heightFeet'$heightInches\" and you currently weigh $weight pounds.</p>";
    echo "<p>Your BMI is $bmi, which is $meaning.</p>";
    echo "<p>Thank you for using the BMI Calculator!</p>";
} else {
?>
<form method="post">
    <label>Name: <input type="text" name="name" required></label><br><br>
    <label>Age: <input type="number" name="age" required></label><br><br>
    <label>Gender:
        <select name="gender" required>
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select>
    </label><br><br>
    <label>Height (feet): <input type="number" name="heightFeet" required></label><br><br>
    <label>Height (inches): <input type="number" name="heightInches" required></label><br><br>
    <label>Weight (pounds): <input type="number" name="weight" required></label><br><br>
    <input type="submit" value="Calculate BMI">
</form>
<?php } ?>
</body>
</html>

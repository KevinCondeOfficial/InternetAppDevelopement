<?php
// math_calculator.php
//Kevin Conde
?>
<!DOCTYPE html>
<html>
<head><title>Basic Math Calculator</title></head>
<body>
<h2>Basic Math Calculator</h2>
<?php
function calculate($num1, $num2, $operator) {
    switch ($operator) {
        case '+': return $num1 + $num2;
        case '-': return $num1 - $num2;
        case '*': return $num1 * $num2;
        case '/': return $num2 != 0 ? $num1 / $num2 : "Error: Division by zero";
        case '%': return $num2 != 0 ? $num1 % $num2 : "Error: Division by zero";
        case '^': return pow($num1, $num2);
        case 'sqrt': return sqrt($num1);
        case 'sin': return sin($num1);
        case 'asin': return asin($num1);
        case 'cos': return cos($num1);
        case 'acos': return acos($num1);
        case 'tan': return tan($num1);
        case 'atan': return atan($num1);
        case 'atan2': return atan2($num1, $num2);
        case 'ceil': return ceil($num1);
        case 'abs': return abs($num1);
        case 'floor': return floor($num1);
        case 'max': return max($num1, $num2);
        case 'min': return min($num1, $num2);
        case 'log': return log($num1);
        case 'log10': return log10($num1);
        case 'log2': return log($num1, 2);
        case 'round': return round($num1);
        default: return "Error: Unknown operator";
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num1 = floatval($_POST["number1"]);
    $num2 = floatval($_POST["number2"]);
    $operator = $_POST["operator"];
    $result = calculate($num1, $num2, $operator);
    echo "<h3>Result: $result</h3><br>";
}
?>
<form method="post">
    <label>First Number: <input type="number" name="number1" step="any" required></label><br><br>
    <label>Second Number: <input type="number" name="number2" step="any"></label><br><br>
    <label>Operator:
        <select name="operator" required>
            <option value="+">Addition (+)</option>
            <option value="-">Subtraction (-)</option>
            <option value="*">Multiplication (*)</option>
            <option value="/">Division (/)</option>
            <option value="%">Modulus (%)</option>
            <option value="^">Exponent (^)</option>
            <option value="sqrt">Square Root (sqrt)</option>
            <option value="sin">Sine (sin)</option>
            <option value="asin">Arcsin (asin)</option>
            <option value="cos">Cosine (cos)</option>
            <option value="acos">Arccos (acos)</option>
            <option value="tan">Tangent (tan)</option>
            <option value="atan">Arctangent (atan)</option>
            <option value="atan2">Arctangent2 (atan2)</option>
            <option value="ceil">Ceil</option>
            <option value="floor">Floor</option>
            <option value="abs">Absolute</option>
            <option value="round">Round</option>
            <option value="max">Maximum</option>
            <option value="min">Minimum</option>
            <option value="log">Natural Log</option>
            <option value="log10">Log Base 10</option>
            <option value="log2">Log Base 2</option>
        </select>
    </label><br><br>
    <input type="submit" value="Calculate">
</form>
</body>
</html>

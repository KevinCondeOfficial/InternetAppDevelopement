<?php
// birthday_meaning.php
?>
<!DOCTYPE html>
<html>
<head><title>Birthday Date Meaning Generator</title></head>
<body>
<?php
function getMonthMeaning($month) {
    $meanings = [1 => "Janus", 2 => "Renewal", 3 => "Mars", 4 => "Rebirth", 5 => "Growth", 6 => "Midyear",
                 7 => "Independence", 8 => "Strength", 9 => "Reflection", 10 => "Change", 11 => "Gratitude", 12 => "Celebration"];
    return $meanings[$month] ?? "Unknown";
}
function getDayMeaning($day) {
    $meanings = [1 => "Self-Starter", 2 => "Diplomatic", 3 => "Creative", 4 => "Hardworking", 5 => "Adventurous",
                 6 => "Caring", 7 => "Spiritual", 8 => "Ambitious", 9 => "Compassionate"];
    return $meanings[$day] ?? "Unique";
}
function getYearMeaning($year) {
    if ($year >= 2000 && $year <= 2009) return "you are a millennial";
    if ($year >= 2010 && $year <= 2019) return "you are part of Gen Z";
    if ($year >= 2020 && $year <= 2023) return "you are a pandemic-era baby";
    return "an unknown generation";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $month = (int)$_POST["month"];
    $day = (int)$_POST["day"];
    $year = (int)$_POST["year"];

    echo "<h2>Birthday Meaning Results:</h2>";
    echo "<p>The month of $month means " . getMonthMeaning($month) . ".</p>";
    echo "<p>The $day" .
         ($day % 10 == 1 && $day != 11 ? "st" : ($day % 10 == 2 && $day != 12 ? "nd" : ($day % 10 == 3 && $day != 13 ? "rd" : "th"))) .
         " of the month means " . getDayMeaning($day) . ".</p>";
    echo "<p>The year of $year means " . getYearMeaning($year) . ".</p><br>";

    echo '<form method="post"><input type="submit" value="Try another one?"></form>';
} else {
?>
<h2>Welcome to Birthday Date Meaning Generator!</h2>
<form method="post">
    <label>Birth Month (1-12): <input type="number" name="month" min="1" max="12" required></label><br><br>
    <label>Birth Day (1-31): <input type="number" name="day" min="1" max="31" required></label><br><br>
    <label>Birth Year (2000-2023): <input type="number" name="year" min="2000" max="2023" required></label><br><br>
    <input type="submit" value="Submit">
</form>
<?php } ?>
</body>
</html>

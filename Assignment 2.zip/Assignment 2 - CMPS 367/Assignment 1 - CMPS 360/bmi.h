using namespace std;
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stack>
#include <cctype>

int bmi()
{
#pragma region Variables
	struct UserInfo
	{
		int age = 0;
		char gender = ' ';
		string name = " ";
		int heightFeet = 0;
		int heightInches = 0;
		double weight = 0;
		double bmi = 0;
		string bmiMeaning = "";
	} user1;
	#pragma endregion

		cout << "Enter name: ";
		cin.ignore();
		getline(cin, user1.name);

		do
		{
			cout << "Enter age: ";
			cin >> user1.age;
		} while (user1.age < 0 || user1.age > 125);

		do
		{
			cout << "Enter gender (m/f): ";
			cin >> user1.gender;
		} while (user1.gender != 'm' && user1.gender != 'f');

		do
		{
			cout << "Enter height (feet): ";
			cin >> user1.heightFeet;
			cout << "Enter height (inches): ";
			cin >> user1.heightInches;
		} while (user1.heightFeet < 0 && user1.heightInches < 0);
		user1.heightInches += user1.heightFeet * 12;

		do
		{
			cout << "Enter weight in pounds: ";
			cin >> user1.weight;
		} while (user1.weight < 0);

		cout << "\n";

		user1.bmi = 703 * (user1.weight / (pow(user1.heightInches, 2)));

		if (user1.bmi < 16)
		{
			user1.bmiMeaning = "Severe Thinness";
		}
		else if (user1.bmi >= 16 && user1.bmi < 17)
		{
			user1.bmiMeaning = "Moderate Thinness";
		}
		else if (user1.bmi >= 17 && user1.bmi < 18.5)
		{
			user1.bmiMeaning = "Mild Thinness";
		}
		else if (user1.bmi >= 18.5 && user1.bmi < 25)
		{
			user1.bmiMeaning = "Normal";
		}
		else if (user1.bmi >= 25 && user1.bmi < 30)
		{
			user1.bmiMeaning = "Overweight";
		}
		else if (user1.bmi >= 30 && user1.bmi < 35)
		{
			user1.bmiMeaning = "Obese Class 1";
		}
		else if (user1.bmi >= 35 && user1.bmi < 40)
		{
			user1.bmiMeaning = "Obese class 2";
		}
		else if (user1.bmi >= 40)
		{
			user1.bmiMeaning = "Obese Class 3";
		}

		cout << "Hello " << user1.name << ". You're currently " << user1.age << "years old.\n";
		cout << "You're " << user1.heightFeet << "\'" << user1.heightInches << "\" tall.\n";
		cout << "You weight " << user1.weight << "lbs. Your BMI is " << bmi << "\n";
		cout << "This means " << user1.bmiMeaning << "\n";


	return 0;
}
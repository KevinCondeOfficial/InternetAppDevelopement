using namespace std;
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stack>
#include <cctype>

int birth()
{
#pragma region Variables
	struct Info
	{
		int day, year, month, lunar;
	} i1;
#pragma endregion

	cout << "Welcome to Birthday Date Meaning Generator!\n"; //Announces what the program does
	cout << "\n";

#pragma region Input
	cout << "What year were you born (1093 AD = 1093): ";
	cin >> i1.year;
	while (i1.year < 0)
	{
		cout << "Error! Try again: ";
		cin >> i1.year;
	}

	cout << "What month were you born (March = 3): ";
	cin >> i1.month;
	while (i1.month < 1 || i1.month > 12)
	{
		cout << "Error! Try again: ";
		cin >> i1.month;
	} //How to have while statement check if a variable is within an array?

	cout << "What day were you born: ";
	cin >> i1.day;
	while (i1.day < 1 || i1.day > 31)
	{
		cout << "Error! Try again: ";
		cin >> i1.day;
	}

	cout << "\n";
#pragma endregion
#pragma region Output
	cout << "Here is what your birthday says about you: \n";

	i1.lunar = i1.year % 12;
	switch (i1.lunar)
	{
	case 0: cout << "You were born in " << i1.year << " and year of the monkey\n"; break;
	case 1: cout << "You were born in " << i1.year << " and year of the rooster\n"; break;
	case 2: cout << "You were born in " << i1.year << " and year of the dog\n"; break;
	case 3: cout << "You were born in " << i1.year << " and year of the pig\n"; break;
	case 4: cout << "You were born in " << i1.year << " and year of the rat\n"; break;
	case 5: cout << "You were born in " << i1.year << " and year of the ox\n"; break;
	case 6: cout << "You were born in " << i1.year << " and year of the tiger\n"; break;
	case 7: cout << "You were born in " << i1.year << " and year of the rabbit\n"; break;
	case 8: cout << "You were born in " << i1.year << " and year of the dragon\n"; break;
	case 9: cout << "You were born in " << i1.year << " and year of the snake\n"; break;
	case 10: cout << "You were born in " << i1.year << " and year of the horse\n"; break;
	case 11: cout << "You were born in " << i1.year << " and year of the goat\n"; break;
	}

	switch (i1.month)
	{
	case 1: cout << "Being born in January means your more likely to like summer.\n"; break;
	case 2: cout << "Being born in February means your more likely to like apples.\n"; break;
	case 3: cout << "Being born in March means your more likely to like playstation.\n"; break;
	case 4: cout << "Being born in April means your more likely to like spring.\n"; break;
	case 5: cout << "Being born in May means your more likely to like mondays.\n"; break;
	case 6: cout << "Being born in June means your more likely to like starbucks.\n"; break;
	case 7: cout << "Being born in July means your more likely to like fireworks.\n"; break;
	case 8: cout << "Being born in August means your more likely to like fall.\n"; break;
	case 9: cout << "Being born in Spetember means your more likely to like xbox.\n"; break;
	case 10: cout << "Being born in October means your more likely to like iPhone.\n"; break;
	case 11: cout << "Being born in November means your more likely to like winter.\n"; break;
	case 12: cout << "Being born in December means your more likely to like christmas.\n"; break;
	}

	switch (i1.day % 6)
	{
	case 0: cout << "People born on the " << i1.day << " day of the month are smart.\n"; break;
	case 1: cout << "People born on the " << i1.day << " day of the month are dumb.\n"; break;
	case 2: cout << "People born on the " << i1.day << " day of the month are nice.\n"; break;
	case 3: cout << "People born on the " << i1.day << " day of the month are mean.\n"; break;
	case 4: cout << "People born on the " << i1.day << " day of the month are cool\n"; break;
	case 5: cout << "People born on the " << i1.day << " day of the month are losers.\n"; break;
	}

	cout << "\n";

#pragma endregion
	cout << "\n";
	return 0;
}
using namespace std;
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stack>
#include <cctype>
//Header files
#include "calc.h"
#include "birth.h"
#include "bmi.h"
#include "multiply.h"
#include "compCalc.h"

int main()
{
	struct mainStruct
	{
		int keepGoing = 1;
		char choice2 = 'y';
		int choice = 0;
	} m1;
	
	cout << setfill('.');

	while (m1.keepGoing == 1)
	{
		cout << "This program can do 5 things:\n";
		cout << left << setw(10) << "1" << right << setw(10) << "Calculator\n";
		cout << left << setw(10) << "2" << right << setw(10) << "Birth Meaning\n";
		cout << left << setw(10) << "3" << right << setw(10) << "BMI Calculator\n";
		cout << left << setw(10) << "4" << right << setw(10) << "Times Table\n";
		cout << left << setw(10) << "5" << right << setw(10) << "Complicated Calculator\n";
	
		cout << "\n";

		cout << "What would you like to do: ";
		cin >> m1.choice;

		cout << "\n";

		switch (m1.choice)
		{
		case 1:
			calc();
			break;
		case 2:
			birth();
			break;
		case 3:
			bmi();
			break;
		case 4:
			multiply();
			break;
		case 5:
			compCalc();
			break;
		default:
			cout << "Not a choice\n";
			break;
		}

		cout << "Would you like to do something else (y/n): ";
		cin >> m1.choice2;
	
		if (m1.choice2 == 'y' || m1.choice2 == 'Y')
		{
			m1.keepGoing = 1;
		}
		else
		{
			m1.keepGoing = 0;
		}
	}

	system("pause");
	return 0;
}
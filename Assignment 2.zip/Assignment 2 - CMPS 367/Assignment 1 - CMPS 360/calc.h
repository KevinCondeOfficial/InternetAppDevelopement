using namespace std;
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stack>
#include <cctype>

int getOperation(char op)
{
    if (op == '+' || op == '-')
    {
        return 1;
    }
    else if (op == '*' || op == '/')
    {
        return 2;
    }
    else if (op == '^')
    {
        return 3;
    }

    return 0;  // Default precedence for non-operators
}

bool isOperator(char c)
{
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

float calculate(const string& equation) 
{
    stack<float> operands;
    stack<char> operators;

    for (size_t i = 0; i < equation.length(); ++i)
    {
        // Skip spaces
        if (isspace(equation[i]))
        {
            continue; 
        }

        if (isdigit(equation[i]) || (i == 0 && equation[i] == '-')) 
        {
            // Read the entire number (including decimals)
            size_t j = i;
            while (j < equation.length() && (isdigit(equation[j]) || equation[j] == '.'))
            {
                ++j;
            }
            string numStr = equation.substr(i, j - i);
            float num = stof(numStr);
            operands.push(num);
            i = j - 1;  // Move the index to the last digit of the number
        }
        else if (equation[i] == '(') 
        {
            operators.push('(');
        }
        else if (equation[i] == ')')
        {
            while (!operators.empty() && operators.top() != '(') 
            {
                // Process operators inside the parentheses
                char op = operators.top();
                operators.pop();

                float right = operands.top();
                operands.pop();

                float left = operands.top();
                operands.pop();

                if (op == '+') 
                {
                    operands.push(left + right);
                }
                else if (op == '-') 
                {
                    operands.push(left - right);
                }
                else if (op == '*') 
                {
                    operands.push(left * right);
                }
                else if (op == '/') 
                {
                    operands.push(left / right);
                }
                else if (op == '^')
                {
                    operands.push(pow(left, right));
                }
            }
            operators.pop();  // Remove the '('
        }
        else if (isOperator(equation[i]))
        {
            while (!operators.empty() && getOperation(operators.top()) >= getOperation(equation[i]))
             {
                    // Process operators with higher or equal precedence
                    char op = operators.top();
                    operators.pop();

                    float right = operands.top();
                    operands.pop();

                    float left = operands.top();
                    operands.pop();

                    if (op == '+') 
                    {
                        operands.push(left + right);
                    }
                    else if (op == '-') 
                    {
                        operands.push(left - right);
                    }
                    else if (op == '*') 
                    {
                        operands.push(left * right);
                    }
                    else if (op == '/') 
                    {
                        operands.push(left / right);
                    }
                    else if (op == '^')
                    {
                        operands.push(pow(left, right));
                    }
             }
            operators.push(equation[i]);
        }
    }

    // Process any remaining operators
    while (!operators.empty()) 
    {
        char op = operators.top();
        operators.pop();

        float right = operands.top();
        operands.pop();

        float left = operands.top();
        operands.pop();

        if (op == '+')
        {
            operands.push(left + right);
        }
        else if (op == '-') 
        {
            operands.push(left - right);
        }
        else if (op == '*') 
        {
            operands.push(left * right);
        }
        else if (op == '^')
        {
            operands.push(pow(left, right));
        }
        else if (op == '/') 
        {
            operands.push(left / right);
        }
    }

    // The final result is on the top of the operands stack
    return operands.top();
}

int calc()
{
    struct Input
    {
        string userProblem;
        char solveAnother;
    } in;
    
    do
    {
        // Get user input
        cout << "Enter a math problem: ";
        getline(cin, in.userProblem);

        // Solve the problem
        float result = calculate(in.userProblem);

        // Display the result
        cout << "Answer: " << result << endl;

        // Ask if the user wants to solve another problem
        cout << "Do you want to solve another problem? (y/n): ";
        cin >> in.solveAnother;
        cin.ignore();  // Clear the newline character from the buffer

    } while (in.solveAnother == 'y' || in.solveAnother == 'Y');

    cout << "Thank you for using the calculator. Goodbye!" << endl;

    return 0;
}
using namespace std;
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stack>
#include <cctype>

#pragma region Variables
double add(double a, double b)
{
    return a + b;
}

double subtract(double a, double b)
{
    return a - b;
}

double multiply(double a, double b)
{
    return a * b;
}

double divide(double a, double b) 
{
    if (b != 0)
    {
        return a / b;
    }
    else 
    {
        cout << "Error: Division by zero!" << endl;
        return NAN;
    }
}

int modulo(int a, int b)
{
    return a % b;
}

double exponent(double base, double exponent)
{
    return pow(base, exponent);
}

double sine(double x) 
{
    return sin(x);
}

double arcsine(double x) 
{
    return asin(x);
}

double cosine(double x) 
{
    return cos(x);
}

double arccosine(double x) 
{
    return acos(x);
}

double tangent(double x) 
{
    return tan(x);
}

double arctangent(double x) 
{
    return atan(x);
}

double arctangent2(double y, double x) 
{
    return atan2(y, x);
}

double squareRoot(double x)
{
    return sqrt(x);
}

double ceiling(double x)
{
    return ceil(x);
}

double absolute(double x)
{
    return abs(x);
}

double floorValue(double x) 
{
    return floor(x);
}

double maximum(double x, double y)
{
    return max(x, y);
}

double minimum(double x, double y)
{
    return min(x, y);
}

double logarithm(double x) 
{
    return log(x);
}

double logarithm10(double x) 
{
    return log10(x);
}

double logarithm2(double x)
{
    return log2(x);
}

double roundValue(double x) 
{
    return round(x);
}
#pragma endregion

int compCalc()
{
    struct Variable
    {
        string operand;
        double num1, num2;
    } v;
    
    cout << "Enter the operand: ";
    cin >> v.operand;

    if (v.operand != "sin" && v.operand != "asin" && v.operand != "cos" && v.operand != "acos" && v.operand != "tan" && v.operand != "atan" && v.operand != "atan2")
    {
        cout << "Enter two numbers: ";
        cin >> v.num1 >> v.num2;
    }
    else
    {
        cout << "Enter one number: ";
        cin >> v.num1;
    }

    if (v.operand == "+" || v.operand == "-" || v.operand == "*" || v.operand == "/" || v.operand == "%" || v.operand == "^")
    {
        switch (v.operand[0])
        {
        case '+':
            cout << "Result: " << add(v.num1, v.num2) << endl;
            break;
        case '-':
            cout << "Result: " << subtract(v.num1, v.num2) << endl;
            break;
        case '*':
            cout << "Result: " << multiply(v.num1, v.num2) << endl;
            break;
        case '/':
            cout << "Result: " << divide(v.num1, v.num2) << endl;
            break;
        case '%':
            cout << "Result: " << modulo(static_cast<int>(v.num1), static_cast<int>(v.num2)) << endl;
            break;
        case '^':
            cout << "Result: " << exponent(v.num1, v.num2) << endl;
            break;
        default:
            cout << "Invalid operand!" << endl;
        }
    }
    else 
    {
        if (v.operand == "sin")
        {
            cout << "Result: " << sine(v.num1) << endl;
        }
        else if (v.operand == "asin")
        {
            cout << "Result: " << arcsine(v.num1) << endl;
        }
        else if (v.operand == "cos")
        {
            cout << "Result: " << cosine(v.num1) << endl;
        }
        else if (v.operand == "acos")
        {
            cout << "Result: " << arccosine(v.num1) << endl;
        }
        else if (v.operand == "tan")
        {
            cout << "Result: " << tangent(v.num1) << endl;
        }
        else if (v.operand == "atan")
        {
            cout << "Result: " << arctangent(v.num1) << endl;
        }
        else if (v.operand == "atan2")
        {
            cout << "Result: " << arctangent2(v.num1, v.num2) << endl;
        }
        else if (v.operand == "sqrt")
        {
            cout << "Result: " << squareRoot(v.num1) << endl;
        }
        else if (v.operand == "ceil")
        {
            cout << "Result: " << ceiling(v.num1) << endl;
        }
        else if (v.operand == "abs")
        {
            cout << "Result: " << absolute(v.num1) << endl;
        }
        else if (v.operand == "floor")
        {
            cout << "Result: " << floorValue(v.num1) << endl;
        }
        else if (v.operand == "max")
        {
            cout << "Result: " << maximum(v.num1, v.num2) << endl;
        }
        else if (v.operand == "min")
        {
            cout << "Result: " << minimum(v.num1, v.num2) << endl;
        }
        else if (v.operand == "log")
        {
            cout << "Result: " << logarithm(v.num1) << endl;
        }
        else if (v.operand == "log10")
        {
            cout << "Result: " << logarithm10(v.num1) << endl;
        }
        else if (v.operand == "log2")
        {
            cout << "Result: " << logarithm2(v.num1) << endl;
        }
        else if (v.operand == "round")
        {
            cout << "Result: " << roundValue(v.num1) << endl;
        }
        else
        {
            cout << "Invalid operand!" << endl;
        }
    }

    return 0;
}
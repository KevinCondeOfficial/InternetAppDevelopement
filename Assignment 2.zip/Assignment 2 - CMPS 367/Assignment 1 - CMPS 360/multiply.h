using namespace std;
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stack>
#include <cctype>

int multiply()
{
#pragma region Variable
	struct Ranges
	{
		int range1;
		int range2;
	} r1;
#pragma endregion

	cout << "Hello, if your ready to generate a times table enter your ranges.\n";
	cout << "Enter range 1: ";
	cin >> r1.range1;
	cout << "Enter range 2: ";
	cin >> r1.range2;

	cout << setfill(' ');

	for (int i = 1; i <= r1.range1; i++)
	{
		for (int x = 1; x <= r1.range2; x++)
		{
			cout << left << setw(6) <<  i * x;
		}
		cout << "\n";
	}

	return 0;
}